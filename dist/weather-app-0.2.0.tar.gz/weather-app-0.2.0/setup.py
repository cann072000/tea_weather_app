from setuptools import setup, find_packages

setup(
    name='weather-app',
    version='0.2.0',
    packages=find_packages(),
    install_requires=[
        'requests==2.26.0',  # Örnek bir bağımlılık, ihtiyaca göre güncelleyebilirsiniz
        # Diğer bağımlılıkları buraya ekleyin
    ],
    entry_points={
        'console_scripts': [
            'weather-app=weather_app.main:main',
        ],
    },
)
